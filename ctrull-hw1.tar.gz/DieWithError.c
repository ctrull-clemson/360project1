/****************************************************************************************************************
*
* Author name: Christian Trull
*
* Module Name: Error print source 
*
* File Name:   DieWithError.c
*
* Summary:
*  This file contains the code that prints out the error message if the program enters a bad state.
*
****************************************************************************************************************/

#include <stdio.h>  /* for perror() */
#include <stdlib.h> /* for exit() */

void DieWithError(char *errorMessage)
{
    perror(errorMessage);
    exit(1);
}
