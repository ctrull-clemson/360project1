/****************************************************************************************************************
*
* Author name: Christian Trull
*
* Module Name: Value server source 
*
* File Name:   valueServer.c
*
* Summary:
*  This file contains the code that generates the random guess value, or uses the first provided number from 
*     the command line, and responds to a client's guess with a high, low, or correct message. If the guess is
*     high then 1 is returned; if the guess is low then 2 is returned; if the guess is correct 0 is returned and
*     a new random value is generated. When the server is stopped an output message with the total number of 
*     guesses, the number of correct guesses, and all client IP addresses are printed out. 
*
****************************************************************************************************************/

#include "UDPEcho.h"
#include <time.h>
#include <stdlib.h>
#include <signal.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>

/* Prototypes for additional methods. */
void DieWithError(char *errorMessage);  /* External error handling function */
void checkIPAddress(struct sockaddr_in sock);
void initIPArray();


char ipaddresses[50][17];                                 /* Array that holds all IP addresses that connect to the server */
int guessCount = 0, correctGuesses = 0, ipCount = 0, i;   /* Counters that are used for print statemetns at the end */
int execute;

/* Prints out results at the end of the server's execution. */
void trap(int signal) 
{
  signal = 0;
  printf("\n%d  %d  ", guessCount, correctGuesses);
  
  // Prints out all IP addresses that were found during execution. 
  for(i = 0; i < ipCount; i++)
  { printf("%s, ", ipaddresses[i]); }
  
  printf("\n"); // Prints final new line for readability.
  exit(0);
}

// Server code which will generate the targetPassword which clients will attempt to guess
int main(int argc, char *argv[])
{
    srand (time(NULL));
    int sock;                                                   /* Socket */
    struct sockaddr_in echoServAddr;                            /* Local address */
    struct sockaddr_in echoClntAddr;                            /* Client address */
    unsigned int cliAddrLen;                                    /* Length of incoming message */
    char echoBuffer[ECHOMAX];                                   /* Buffer for echo string */
    unsigned short echoServPort;                                /* Server port */
    int recvMsgSize, returnLength;                              /* Size of received message */
    double constraint = (double) 1000000000/RAND_MAX;           /* Use to keep random value in valid range */
    int guessVal, targetPassword = rand() * constraint, i = 0;  /* Target value and current guess' value */ 
    
    signal(SIGINT, &trap);
    execute = 1;
    
    // Checks input parameters and assigns values to the correct variables based on flags.
    while(execute)
    {    
      if (!((argc == 3) || (argc == 5)))    /* Test for correct number of arguments */
      {
          fprintf(stderr,"Incorrect number of parameters passed in.\n");
          exit(1);
      }
      
      for(i = 0; i < argc; i++)
      {
        // Flag for what parameter the next value is.
        if ((i == 1) || (i == 3))
        {
          /* First arg:  local port */
          if(strcmp(argv[i], "-p") == 0)
          { echoServPort = atoi(argv[i+1]); }
          
          /* Second arg: Optional first password */
          else if(strcmp(argv[i], "-v") == 0)
          { targetPassword = atoi(argv[i+1]); }
          
          /* Incorrect flag was passed in. */
          else
          {
            fprintf(stderr,"Incorrect parameter number %d.\n", i);
            exit(1);        
          }        
        }
      }

      /* Create socket for sending/receiving datagrams */
      if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
          DieWithError("socket() failed");
      
      /* Construct local address structure */
      memset(&echoServAddr, 0, sizeof(echoServAddr));   /* Zero out structure */
      echoServAddr.sin_family = AF_INET;                /* Internet address family */
      echoServAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
      echoServAddr.sin_port = htons(echoServPort);      /* Local port */
 
      /* Bind to the local address */
      printf("UDPEchoServer: About to bind to port %d\n", echoServPort);    
      if (bind(sock, (struct sockaddr *) &echoServAddr, sizeof(echoServAddr)) < 0)
          DieWithError("bind() failed");
      
      for (;;) /* Run forever */
      {
          /* Set the size of the in-out parameter */
          cliAddrLen = sizeof(echoClntAddr);

          /* Block until receive message from a client */
          if ((recvMsgSize = recvfrom(sock, echoBuffer, ECHOMAX, 0,
              (struct sockaddr *) &echoClntAddr, &cliAddrLen)) < 0)
              DieWithError("recvfrom() failed");  
          
          // Determine if this is a new IP address or not
          checkIPAddress(echoClntAddr);
          
          // Keeping track with current guess and number of guesses
          guessCount += 1;
          guessVal = atoi(echoBuffer);
          memset(echoBuffer,0,strlen(echoBuffer));
                  
          
          if(guessVal == targetPassword) // Return found correct value 0
          {
              strcpy(echoBuffer, "0");
              targetPassword = rand() * constraint;
              correctGuesses += 1;
          }
          
          // Guess value greater than actually value. Return 1
          else if(guessVal > targetPassword) 
          { strcpy(echoBuffer, "1"); }
          
          // Guess value less than actually value. Return 2
          else if(guessVal < targetPassword) 
          { strcpy(echoBuffer, "2"); }
          
          returnLength = strlen(echoBuffer);
          
          /* Send received datagram back to the client */
          if (sendto(sock, echoBuffer, returnLength, 0, 
               (struct sockaddr *) &echoClntAddr, sizeof(echoClntAddr)) != returnLength)
              DieWithError("sendto() sent a different number of bytes than expected");
      }
    }
    signal(SIGINT, SIG_DFL);
    
    return 0;
}

/*
*   Method Name: checkIPAddress
*   
*   Parameters: sock is the socket from the current communication transaction.
*
*   Summary: Determines the IP address of the client and adds it to it's list if this is it's first communication.
*
*/

void checkIPAddress(struct sockaddr_in sock)
{
  char ip[17]; 
  sprintf(ip, "%s", inet_ntoa(sock.sin_addr));  
  
  // Check to see if IP address has already been added to list. if not, then add.
  int already = 0;
  for(i = 0; i < ipCount; i++)
  {
    if(strcmp(ipaddresses[i], ip) == 0)
      already = 1;
  }
  
  if(already == 0)
  {
    sprintf(ipaddresses[ipCount], "%s", ip);
    ipCount += 1;
  }  
}
