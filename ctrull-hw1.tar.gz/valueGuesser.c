/****************************************************************************************************************
*
* Author name: Christian Trull
*
* Module Name: Value guesser source 
*
* File Name:   valueGuesser.c
*
* Summary:
*  This file contains the code that connects to the server and sends guesses. The first guess is generated
*     randomly and then after that the guesser updates the min and max bounds and guesses the median of the two.
*     The client code will exit if the communication with the server times out with the provided port(s). After 
*     a successful guess or if the client's process gets cancelled the total number of guesses, time elapsed in 
*     microseconds, and the correct guess number.
*
****************************************************************************************************************/
#include "UDPEcho.h"
#include <signal.h>
#include <time.h>
#include <string.h>
#include <sys/time.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>

// Prototypes for the alarm handler and guess generating methods
void CatchAlarm(int ignored); // Handler for SIGALRM
int generateMedian();

// Variables that are used for terminating print statements
struct timeval tvalBefore, tvalAfter;
int guess, guessCount;

// Variables that control how long each timeout should last, and number of tries before terminating.
static const unsigned int TIMEOUT = 2;
static const unsigned int MAXTRIES = 3;
unsigned int tries = 0;

// SIGINT trap that prints out terminating information if the client doesnt guess correctly.
void trap(int signal) 
{
  signal = 0;
  gettimeofday(&tvalAfter, NULL);
  printf("\n%d  %ld  %d\n", guessCount, ((tvalAfter.tv_sec - tvalBefore.tv_sec)*1000000L+tvalAfter.tv_usec)-tvalBefore.tv_usec, guess);
  exit(0);
}

// Client code which sends guesses to the server it connects to.
int main(int argc, char *argv[])
{
    srand (time(NULL));
    
    int sock;                                            /* Socket descriptor */
    struct sockaddr_in echoServAddr;                     /* Echo server address */
    struct sockaddr_in fromAddr;                         /* Source address of echo */
    struct hostent *thehost;                             /* Hostent from gethostbyname() */
    unsigned short servPort1, servPort2;                 /* Echo server port */
    unsigned int fromSize;                               /* In-out of address size for recvfrom() */
    char *servIP = NULL;                                 /* IP address of server */
    char echoBuffer[ECHOMAX+1];                          /* Buffer for receiving echoed string */
    char guessBuffer[ECHOMAX+1];                         /* Buffer for sending value */
    int correct = 0;                                     /* Boolean for if correct answer found */
    double constraint = (double) 1000000000/RAND_MAX;    /* use to keep random value in valid range */
    guess = rand() * constraint;                         /* Bounds for guesses and current guess */
    int result;                                          /* Result returned from server */
    int g_min = 0, g_max = 1000000000;                   /* Bounds within which the guess value is calculated from */
    int i = 0;
    guessCount = 0;
    
    signal(SIGINT, &trap);
    gettimeofday(&tvalBefore, NULL);
     
    if (!((argc == 5) || (argc == 7)))    /* Test for correct number of arguments */
    {
        fprintf(stderr,"Incorrect number of parameters passed in.\n");
        exit(1);
    }
    
    // Reads in command line arguments and sets the ports and IP address in the correct variables.
    for(i = 0; i < argc; i++)
    {
      // Flag for what parameter the next value is.
      if ((i == 1) || (i == 3) || (i == 5))
      {
        // The following argument is the server's IP address
        if(strcmp(argv[i], "-s") == 0)
        { servIP = argv[i+1]; }
        
        // The following argument is the first port number
        else if(strcmp(argv[i], "-p1") == 0)
        { servPort1 = atoi(argv[i+1]); }
        
        // The following argument is the second port number
        else if(strcmp(argv[i], "-p2") == 0)
        { servPort2 = atoi(argv[i+1]); }
        
        // The argument is not a valid flag for this program.
        else
        {
          fprintf(stderr,"Incorrect parameter number %d.\n", i);
          exit(1);        
        }        
      }
    }        

    /* Create a datagram/UDP socket */
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
        DieWithError("socket() failed");
    
    /* Construct the server address structure */
    memset(&echoServAddr, 0, sizeof(echoServAddr));    /* Zero out structure */
    echoServAddr.sin_family = AF_INET;                 /* Internet addr family */
    echoServAddr.sin_addr.s_addr = inet_addr(servIP);  /* Server IP address */
    echoServAddr.sin_port   = htons(servPort1);     /* Server port */
     
    /* Sets up the alarm handler for timeouts */
    struct sigaction handler; // Signal handler
    handler.sa_handler = CatchAlarm;
    if(sigfillset(&handler.sa_mask)<0)
      DieWithError("sigfillset() failed");
    handler.sa_flags = 0;
    
    if(sigaction(SIGALRM, &handler, 0) < 0)
      DieWithError("sigaction() failed for SIGALRM");
    
    /* If user gave a dotted decimal address, we need to resolve it  */
    if (echoServAddr.sin_addr.s_addr == -1) {
        thehost = gethostbyname(servIP);
            echoServAddr.sin_addr.s_addr = *((unsigned long *) thehost->h_addr_list[0]);
    }
    
    /* Loop that runs until the client correctly guess the value or times out. */
    while (correct != 1)
    {
      /* Makes guess */
      sprintf(guessBuffer, "%d", guess);
      ssize_t numBytes = sendto(sock, guessBuffer, strlen(guessBuffer), 0, (struct sockaddr *)
                       &echoServAddr, sizeof(echoServAddr));        
      guessCount += 1;
      
      /* Recv a response */   
      fromSize = sizeof(fromAddr);
      
      // Timeout
      alarm(TIMEOUT); // Set the timeout
      while ((numBytes = recvfrom(sock, echoBuffer, ECHOMAX, 0, (struct sockaddr *) &fromAddr, &fromSize) < 0)) 
      {
        if (errno == EINTR)      // Alarm went off
        {
          if (tries < MAXTRIES)  // Incremented by signal handler
          {
            numBytes = sendto(sock, guessBuffer, strlen(guessBuffer), 0, (struct sockaddr *)
                       &echoServAddr, sizeof(echoServAddr));
            if (numBytes < 0)
              DieWithError("sendto() failed");
          } 
          else
          {
            // Change port if havent already. else exit
            if((echoServAddr.sin_port == htons(servPort1)) && (argc == 7))
            {
              tries = 0;
              echoServAddr.sin_port = htons(servPort2);
            }
            else
              DieWithError("No Response unable to communicate with server");
          }
        } else
          DieWithError("recvfrom() failed");
      }
      
      alarm(0);
    
      if (echoServAddr.sin_addr.s_addr != fromAddr.sin_addr.s_addr)
      {
          fprintf(stderr,"Error: received a packet from unknown source \n");
      }
      
      result = atoi(echoBuffer);
      
      // Correct guess was sent. While conditional variable set to 1.
      if(result == 0) { correct = 1; }
      
      // Incorrect guess was sent. Guess was too high.
      else if(result == 1)
      {
          g_max = guess;
          guess = generateMedian(g_min, g_max);
      }
      
      // Incorrect gueess was sent. Guess was too low.
      else if(result == 2)
      {
          g_min = guess;
          guess = generateMedian(g_min, g_max);
      }
      
      /* null-terminate the received data */
      echoBuffer[numBytes] = '\0';
    }
    
    // Determine total run time and print out in the requested format.
    gettimeofday(&tvalAfter, NULL);    
    printf("%d  %ld  %d\n", guessCount, ((tvalAfter.tv_sec - tvalBefore.tv_sec)*1000000L+tvalAfter.tv_usec)-tvalBefore.tv_usec, guess);
    
    close(sock);
    exit(0);
}

/*
*   Method Name: generateMedian
*   
*   Parameters: low is the lowest bound for the range the guess could be in. high is the upper bound.
*
*   Summary: Calculates the median value between the bounds which will be used as the next guess
*
*/
int generateMedian(int low, int high)
{
    int median = ((high - low) / 2) + low;
    
    if(median == high)
        median = median - 1;
    else if(median == low)
        median = median + 1;
    
    return median;
}

// Handler for SIGALRM
void CatchAlarm(int ignored)
{
  tries += 1;
  alarm(TIMEOUT);
}

