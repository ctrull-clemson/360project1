---------------------------------------------------------------------------
Package:  ctrull-hw1.tar.gz

Explanation:  

This package contains a client and server pair which connects over UDP 
sockets and attempts to guess a value determined by the server. The created
executables are: valueServer and valueGuesser. Once the client starts it
will send a random number between 0 and 1 billion to the server. Once the 
server is started it will compare the guess to a number in the same range,
either from an input parameter or randomly, and reply with either low, high,
or correct to the client in the form of 2, 1, or 0 respectively. If the 
client was incorrect, it updates it's guess range and sends a new guess.
This cycle repeats for the client until it is correct, and once it is exits
after printing total number of guesses, time it took to execute in 
microseconds and the correct value. The server will sit and wait until a 
client sends a guess and on exit will print out the total number of guess,
total number of correct guesses, and a list of all IPv4 address that 
connected to it during execution.

---------------------------------------------------------------------------
Unpacking Instructions: 

Copy the ctrull-hw1.tar.gz package into a directory that you will use to
build and run the program from.  Issue the following commands:

>gzip -d ctrull-hw1.tar.gz
>tar -xf ctrull-hw1.tar

When done, you should see the following files:

DieWithError.c    Make.defines    Makefile        Makefile.bak  readme.html 
readme.txt        UDPEcho.h       valueGuesser.c  valueServer.c

---------------------------------------------------------------------------
Build Instructions:
When you download this package, issue the following to build:
>make clean
>make depend
>make


---------------------------------------------------------------------------
Invocation:


./valueServer -p <serverPort> [-v initialValue]
  -First parameter is the flag denoting the following value as the port 
      number the server should use.
  -The second parameter is the port the server should use.
  -The third parameter is an optional parameter to denote first 
      desired password.
  -The fourth parameter is an optional parameter that is the desired 
      first password.
  -The order of the flag and respective value can be in either order, 
      but must be paired as *flag* *value*
        - ex: "./valueServer -v 500 -p 5555" is a valid call

./valueGuesser -s <serverIP> -p1 <serverPort1> -p2 <serverPort2>
  -First parammeter is the flag denoting the server IP address
  -The second parameters is the server's IP address in dotted decimal 
      format or as a domain name.
  -The third parameter is the flag denoting the first server port
  -The fourth parameter is the desired first port to connect to.
  -The fifth parameter is the flag denoting the second server port
  -The sixth parameter is the desired second port to connect to.
  -The order of the flags and respective values can be in any order,
      but must be paired as *flag* *value*
      

---------------------------------------------------------------------------
